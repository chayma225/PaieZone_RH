import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate, query, stagger } from '@angular/animations';

import IconComponent from '../../core/icon/icon.component';

// pz-emp-requests — "Mes demandes" : tuiles d'action + historique unifié
interface MyRequest {
  ref: string; type: string; detail: string; date: string;
  status: 'approved' | 'pending' | 'rejected';
}

@Component({
  selector: 'pz-emp-requests',
  standalone: true,
  imports: [CommonModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('tiles', [
      transition(':enter', [
        query('.tile', [
          style({ opacity: 0, transform: 'translateY(12px)' }),
          stagger(80, animate('340ms cubic-bezier(.22,1,.36,1)',
            style({ opacity: 1, transform: 'translateY(0)' }))),
        ], { optional: true }),
      ]),
    ]),
    trigger('rows', [
      transition(':enter', [
        query('tbody tr', [
          style({ opacity: 0, transform: 'translateY(8px)' }),
          stagger(45, animate('260ms cubic-bezier(.22,1,.36,1)',
            style({ opacity: 1, transform: 'translateY(0)' }))),
        ], { optional: true }),
      ]),
    ]),
  ],
  template: `
    <div class="pz-page">
      <div class="pz-page-head">
        <div>
          <div class="pz-crumbs"><strong>Mon espace</strong> <span class="sep">/</span> Mes demandes</div>
          <h1>Toutes mes demandes</h1>
          <div class="pz-muted">Suivi de l'ensemble de vos requêtes RH</div>
        </div>
      </div>

      <!-- Tuiles d'action -->
      <div class="tiles" [@tiles]>
        @for (a of actions; track a.title) {
          <button class="pz-card tile">
            <div class="tile-ico"><pz-icon [name]="a.icon" [size]="20"/></div>
            <div class="tile-title">{{ a.title }}</div>
            <div class="pz-muted tile-sub">{{ a.sub }}</div>
            <div class="tile-go">Commencer <pz-icon name="Arrow" [size]="12" [strokeWidth]="1.6"/></div>
          </button>
        }
      </div>

      <!-- Historique -->
      <div class="pz-card">
        <div class="card-head">
          <div class="card-title">Historique</div>
          <div class="pz-muted small">6 derniers mois</div>
        </div>
        <table class="pz-tbl" [@rows]>
          <thead><tr><th>Réf.</th><th>Type</th><th>Détail</th><th>Date</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            @for (r of requests(); track r.ref) {
              <tr>
                <td class="pz-mono small">{{ r.ref }}</td>
                <td class="strong">{{ r.type }}</td>
                <td class="pz-muted">{{ r.detail }}</td>
                <td class="pz-mono small">{{ r.date }}</td>
                <td>
                  <span class="pz-pill" [class.pos]="r.status === 'approved'" [class.warn]="r.status === 'pending'" [class.danger]="r.status === 'rejected'">
                    <span class="dot"></span>{{ label(r.status) }}
                  </span>
                </td>
                <td><button class="pz-btn pz-sm pz-ghost"><pz-icon name="Eye" [size]="14" [strokeWidth]="1.4"/></button></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; }
    .tiles { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--pz-gap); }
    .tile { text-align: left; padding: 20px; cursor: pointer; border: 1px solid var(--pz-line);
      background: #fff; border-radius: var(--pz-radius-lg, 14px); transition: transform .15s, box-shadow .15s, border-color .15s; }
    .tile:hover { transform: translateY(-3px); box-shadow: var(--pz-shadow-lg); border-color: var(--pz-primary); }
    .tile-ico { width: 44px; height: 44px; border-radius: 11px; background: var(--pz-primary-soft);
      color: var(--pz-primary); display: grid; place-items: center; }
    .tile-title { font-size: 15px; font-weight: 600; margin-top: 14px; }
    .tile-sub { font-size: 12.5px; margin-top: 4px; line-height: 1.5; }
    .tile-go { display: flex; align-items: center; gap: 6px; margin-top: 14px; color: var(--pz-primary);
      font-size: 13px; font-weight: 600; }
    .card-head { padding: 16px 20px 12px; display: flex; align-items: baseline; gap: 10px; }
    .card-head .small { margin-left: auto; }
    .card-title { font-size: 14px; font-weight: 600; }
    .small { font-size: 11.5px; }
    .strong { font-weight: 600; }
    .pz-tbl { width: 100%; border-collapse: collapse; }
    .pz-tbl thead th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .05em;
      font-weight: 600; color: var(--pz-muted); padding: 10px 16px; border-bottom: 1px solid var(--pz-line);
      background: var(--pz-surface-2); }
    .pz-tbl tbody td { padding: 12px 16px; border-bottom: 1px solid var(--pz-line); font-size: 13px; color: var(--pz-ink-2); }
    .pz-tbl tbody tr:last-child td { border-bottom: 0; }
    .pz-tbl tbody tr:hover { background: var(--pz-surface-2); }
    .pz-mono { font-family: 'JetBrains Mono', monospace; }
    @media (max-width: 1024px) { .tiles { grid-template-columns: 1fr; } }
  `],
})
export default class EmpRequestsComponent {
  protected readonly actions = [
    { icon: 'Calendar', title: 'Demander un congé', sub: 'Posez vos congés payés, RTT ou jours exceptionnels' },
    { icon: 'Cash', title: 'Demander une avance', sub: 'Sollicitez une avance sur votre prochain salaire' },
    { icon: 'Doc', title: 'Demander un document', sub: 'Attestation employeur, certificat, etc.' },
  ];

  protected readonly requests = signal<MyRequest[]>([
    { ref: 'AV-117', type: 'Avance sur salaire', detail: '500 TND · Remboursement sur 2 mois', date: '13/05/2026', status: 'pending' },
    { ref: 'LV-2810', type: 'Congés payés', detail: '4 jours · 28/05 → 31/05', date: '02/05/2026', status: 'approved' },
    { ref: 'AV-101', type: 'Avance sur salaire', detail: '600 TND · Remboursement sur 3 mois', date: '15/03/2026', status: 'approved' },
    { ref: 'DOC-088', type: 'Mise à jour RIB', detail: 'Nouveau RIB Banque de Tunisie', date: '08/03/2026', status: 'approved' },
    { ref: 'DOC-072', type: 'Attestation employeur', detail: 'Pour démarches administratives', date: '20/02/2026', status: 'approved' },
  ]);

  protected label(s: string): string {
    return s === 'approved' ? 'Approuvée' : s === 'pending' ? 'En attente' : 'Refusée';
  }
}
