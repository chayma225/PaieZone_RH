import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate, query, stagger } from '@angular/animations';

import IconComponent from '../../core/icon/icon.component';
import { DataService } from '../../core/data.service';

// pz-emp-leaves — "Mes congés" : soldes en anneaux animés + historique
interface MyLeave {
  id: string; type: string; days: number; from: string; to: string;
  status: 'approved' | 'pending' | 'rejected'; submitted: string;
}

@Component({
  selector: 'pz-emp-leaves',
  standalone: true,
  imports: [CommonModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('cards', [
      transition(':enter', [
        query('.bal-card', [
          style({ opacity: 0, transform: 'translateY(12px)' }),
          stagger(70, animate('320ms cubic-bezier(.22,1,.36,1)',
            style({ opacity: 1, transform: 'translateY(0)' }))),
        ], { optional: true }),
      ]),
    ]),
    trigger('rows', [
      transition(':enter', [
        query('tbody tr', [
          style({ opacity: 0, transform: 'translateY(8px)' }),
          stagger(45, animate('260ms cubic-bezier(.22,1,.36,1)',
            style({ opacity: 1, transform: 'translateY(0)' }))),
        ], { optional: true }),
      ]),
    ]),
  ],
  template: `
    <div class="pz-page">
      <div class="pz-page-head">
        <div>
          <div class="pz-crumbs"><strong>Mon espace</strong> <span class="sep">/</span> Mes congés</div>
          <h1>Mes congés & absences</h1>
          <div class="pz-muted">Consultez vos soldes et déposez vos demandes</div>
        </div>
        <div class="pz-page-actions">
          <button class="pz-btn pz-primary"><pz-icon name="Plus" [size]="14" [strokeWidth]="1.7"/> Nouvelle demande</button>
        </div>
      </div>

      <!-- Soldes en anneaux -->
      <div class="bal-grid" [@cards]>
        @for (b of balances; track b.label) {
          <div class="pz-card bal-card">
            <div class="ring-wrap">
              <svg width="72" height="72" viewBox="0 0 72 72">
                <circle cx="36" cy="36" r="30" fill="none" stroke="var(--pz-surface-3)" stroke-width="7"/>
                <circle cx="36" cy="36" r="30" fill="none" [attr.stroke]="b.color" stroke-width="7" stroke-linecap="round"
                  [attr.stroke-dasharray]="dash(b.used, b.total)" transform="rotate(-90 36 36)"
                  class="ring"/>
              </svg>
              <div class="ring-ico" [style.color]="b.color"><pz-icon [name]="b.icon" [size]="18"/></div>
            </div>
            <div class="bal-info">
              <div class="pz-muted small">{{ b.label }}</div>
              <div class="bal-num">{{ b.total - b.used }}<span class="pz-muted">/ {{ b.total }}j</span></div>
              <div class="pz-muted small">{{ b.used }} jours pris</div>
            </div>
          </div>
        }
      </div>

      <!-- Historique -->
      <div class="pz-card">
        <div class="card-head"><div class="card-title">Historique de mes demandes</div></div>
        <table class="pz-tbl" [@rows]>
          <thead><tr><th>Réf.</th><th>Type</th><th class="num">Jours</th><th>Période</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            @for (l of myLeaves(); track l.id) {
              <tr>
                <td class="pz-mono small">{{ l.id }}</td>
                <td>{{ l.type }}</td>
                <td class="num strong">{{ l.days }}j</td>
                <td class="pz-mono small">{{ l.from }} → {{ l.to }}</td>
                <td>
                  <span class="pz-pill" [class.pos]="l.status === 'approved'" [class.warn]="l.status === 'pending'" [class.danger]="l.status === 'rejected'">
                    <span class="dot"></span>{{ label(l.status) }}
                  </span>
                </td>
                <td><button class="pz-btn pz-sm pz-ghost"><pz-icon name="Eye" [size]="14" [strokeWidth]="1.4"/></button></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; }
    .pz-page-actions { display: flex; gap: 8px; }
    .bal-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--pz-gap); }
    .bal-card { display: flex; align-items: center; gap: 16px; padding: 18px 20px; }
    .ring-wrap { position: relative; width: 72px; height: 72px; flex-shrink: 0; }
    .ring-ico { position: absolute; inset: 0; display: grid; place-items: center; }
    .ring { transition: stroke-dasharray 1.1s cubic-bezier(.22,1,.36,1); }
    .bal-info { min-width: 0; }
    .bal-num { font-size: 24px; font-weight: 700; letter-spacing: -0.02em; margin-top: 2px; }
    .bal-num span { font-size: 13px; font-weight: 500; margin-left: 4px; }
    .small { font-size: 11.5px; }
    .strong { font-weight: 600; }
    .card-head { padding: 16px 20px 12px; }
    .card-title { font-size: 14px; font-weight: 600; }
    .pz-tbl { width: 100%; border-collapse: collapse; }
    .pz-tbl thead th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .05em;
      font-weight: 600; color: var(--pz-muted); padding: 10px 16px; border-bottom: 1px solid var(--pz-line);
      background: var(--pz-surface-2); }
    .pz-tbl thead th.num, .pz-tbl tbody td.num { text-align: right; font-variant-numeric: tabular-nums; }
    .pz-tbl tbody td { padding: 12px 16px; border-bottom: 1px solid var(--pz-line); font-size: 13px; color: var(--pz-ink-2); }
    .pz-tbl tbody tr:last-child td { border-bottom: 0; }
    .pz-tbl tbody tr:hover { background: var(--pz-surface-2); }
    .pz-mono { font-family: 'JetBrains Mono', monospace; }
    @media (max-width: 1024px) { .bal-grid { grid-template-columns: 1fr 1fr; } }
  `],
})
export default class EmpLeavesComponent {
  protected readonly data = inject(DataService);

  protected readonly balances = [
    { label: 'Congés payés', used: 4, total: 24, color: '#5b21b6', icon: 'Beach' },
    { label: 'RTT', used: 2, total: 11, color: '#0ea5e9', icon: 'Clock' },
    { label: 'Maladie', used: 0, total: 15, color: '#f59e0b', icon: 'Shield' },
    { label: 'Exceptionnel', used: 0, total: 5, color: '#10b981', icon: 'Calendar' },
  ];

  protected readonly myLeaves = signal<MyLeave[]>([
    { id: 'LV-2810', type: 'Congés payés', days: 4, from: '28/05/2026', to: '31/05/2026', status: 'approved', submitted: '02/05/2026' },
    { id: 'LV-2802', type: 'RTT', days: 1, from: '02/05/2026', to: '02/05/2026', status: 'approved', submitted: '20/04/2026' },
    { id: 'LV-2796', type: 'Congés payés', days: 3, from: '08/04/2026', to: '10/04/2026', status: 'approved', submitted: '01/04/2026' },
    { id: 'LV-2780', type: 'Congé exceptionnel', days: 1, from: '14/03/2026', to: '14/03/2026', status: 'approved', submitted: '10/03/2026' },
  ]);

  protected dash(used: number, total: number): string {
    const C = 2 * Math.PI * 30;
    return `${(used / total) * C} ${C}`;
  }
  protected label(s: string): string {
    return s === 'approved' ? 'Approuvée' : s === 'pending' ? 'En attente' : 'Refusée';
  }
}
